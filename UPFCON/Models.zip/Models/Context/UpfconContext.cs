﻿// using System.Data.Entity;
using Microsoft.EntityFrameworkCore;

namespace UPFCON.Models.Context;

public class UpfconContext : DbContext
{
    public UpfconContext() { }
    public UpfconContext(DbContextOptions<UpfconContext> options)
        : base(options) { }
    
    public required DbSet<User> Users { get; set; }
    public required DbSet<Admin> Admins { get; set; }
    public required DbSet<Attendee> Attendees { get; set; }
    public required DbSet<Author> Authors { get; set; }
    public required DbSet<BoardDirector> BoardDirectors { get; set; }
    public required DbSet<BoardDirectorDecision> BoardDirectorDecisions { get; set; }
    public required DbSet<Chairman> Chairmans { get; set; }
    public required DbSet<CommitteeMember> CommitteeMembers { get; set; }
    public required DbSet<Contribution> Contributions { get; set; }
    public required DbSet<Diploma> Diplomas { get; set; }
    public required DbSet<Evaluation> Evaluations { get; set; }
    public required DbSet<Event> Events { get; set; }
    public required DbSet<Paper> Papers { get; set; }
    public required DbSet<Participation> Participations { get; set; }
    public required DbSet<SubmissionRules> SubmissionRules { get; set; }
    public required DbSet<TimeSlot> TimeSlots { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        
        // Defines relationships between entities:
        BoardDirectorDecisionMapping(modelBuilder);
        ContributionMapping(modelBuilder);
        CommitteeMemberMapping(modelBuilder);
        ParticipationMapping(modelBuilder);
        EvaluationMapping(modelBuilder);
        TimeSlotMapping(modelBuilder);

        modelBuilder.Entity<User>()
            .HasIndex(u => u.Email)
            .IsUnique();

        modelBuilder.Entity<User>()
            .HasIndex(u => u.Phone)
            .IsUnique();
    }

    private static void BoardDirectorDecisionMapping(ModelBuilder modelBuilder)
    {
        /*
         * Defining a composite key:
         * BoardDirectorDecision's primary key is made up
         * of both the BoardDirector's ID and the Event's ID
         */
        modelBuilder.Entity<BoardDirectorDecision>()
            .HasKey(bdd => new { bdd.BoardDirectorId, bdd.EventId });

        /*
         * Defining a * -> 1 -> * relationship (or * -> * relationship
         * with a join table defined manually)
         */
        modelBuilder.Entity<BoardDirectorDecision>()
            .HasOne(bdd => bdd.BoardDirector)
            // .WithMany()
            // .HasRequired(bdd => bdd.BoardDirector)
            .WithMany(bd => bd.Decisions)
            .HasForeignKey(bdd => bdd.BoardDirectorId);
        
        modelBuilder.Entity<BoardDirectorDecision>()
            .HasOne(bdd => bdd.Event)
            // .HasRequired(bdd => bdd.Event)
            .WithMany(e => e.BoardDecisions)
            .HasForeignKey(bdd => bdd.EventId);
    }

    private static void ContributionMapping(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Contribution>()
            .HasKey(c => new { c.AuthorId, c.PaperId });
        
        modelBuilder.Entity<Contribution>()
            // .HasRequired(c => c.Author)
            .HasOne(c => c.Author)
            .WithMany(a => a.Contributions)
            .HasForeignKey(c => c.AuthorId);
        
        modelBuilder.Entity<Contribution>()
            // .HasRequired(c => c.Paper)
            .HasOne(c => c.Paper)
            .WithMany(p => p.Contributors)
            .HasForeignKey(c => c.PaperId);
    }

    private static void CommitteeMemberMapping(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<CommitteeMember>()
            .HasKey(cm => new {cm.ChairmanId, cm.EventId });

        modelBuilder.Entity<CommitteeMember>()
            .HasOne(cm => cm.Chairman)
            // .HasRequired(cm => cm.Chairman)
            .WithMany(c => c.Memberships)
            .HasForeignKey(cm => cm.ChairmanId);
        
        modelBuilder.Entity<CommitteeMember>()
            // .HasRequired(cm => cm.Event)
            .HasOne(cm => cm.Event)
            .WithMany(e => e.OrganizingCommittee)
            .HasForeignKey(cm => cm.EventId);
    }

    private static void ParticipationMapping(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Participation>()
            .HasKey(p => new { p.AttendeeId, p.EventId });
        
        modelBuilder.Entity<Participation>()
            .HasOne(p => p.Attendee)
            // .HasRequired(p => p.Attendee)
            .WithMany(a => a.Events)
            .HasForeignKey(p => p.AttendeeId);
        
        modelBuilder.Entity<Participation>()
            .HasOne(p => p.Event)
            // .HasRequired(p => p.Event)
            .WithMany(e => e.Attendees)
            .HasForeignKey(p => p.EventId);
    }

    private static void EvaluationMapping(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Evaluation>()
            .HasOne(e => e.Evaluator)
            // .HasRequired(e => e.Evaluator)
            .WithMany(cm => cm.Evaluations)
            .HasForeignKey(e => new { e.EvaluatorId, e.EventId})
            .OnDelete(DeleteBehavior.Restrict);
        
        modelBuilder.Entity<Evaluation>()
            .HasOne(p => p.Paper)
            // .HasRequired(e => e.Paper)
            .WithMany(p => p.Evaluations)
            .HasForeignKey(e => e.PaperId)
            .OnDelete(DeleteBehavior.Restrict);
    }

    private void TimeSlotMapping(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<TimeSlot>()
            .HasKey(ts => new { ts.EventId, ts.PaperId });

        modelBuilder.Entity<TimeSlot>()
            .HasOne(ts => ts.Paper)
            .WithOne(ts => ts.TimeSlot)
            .HasForeignKey<TimeSlot>(ts => ts.PaperId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<TimeSlot>()
            .HasOne(ts => ts.Event)
            .WithMany(e => e.Planning)
            .HasForeignKey(ts => ts.EventId)
            .OnDelete(DeleteBehavior.Restrict);
    }
    
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if (!optionsBuilder.IsConfigured)
        {
            optionsBuilder.UseSqlServer(
                "Data Source=(localdb)\\MSSQLLocalDB;" + 
                "Initial Catalog=UPFCON;" + 
                "Integrated Security=True;" +
                "TrustServerCertificate=True;"
            );
        }
    }

    
}