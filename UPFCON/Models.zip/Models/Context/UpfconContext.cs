﻿using System.Data.Entity;

namespace UPFCON.Models.Context;

public class UpfconContext : DbContext
{
    public required DbSet<User> Users { get; set; }
    public required DbSet<Admin> Admins { get; set; }
    public required DbSet<Attendee> Attendees { get; set; }
    public required DbSet<Author> Authors { get; set; }
    public required DbSet<BoardDirector> BoardDirectors { get; set; }
    public required DbSet<BoardDirectorDecision> BoardDirectorDecisions { get; set; }
    public required DbSet<Chairman> Chairmans { get; set; }
    public required DbSet<CommitteeMember> CommitteeMembers { get; set; }
    public required DbSet<Contribution> Contributions { get; set; }
    public required DbSet<Diploma> Diplomas { get; set; }
    public required DbSet<Evaluation> Evaluations { get; set; }
    public required DbSet<Event> Events { get; set; }
    public required DbSet<Paper> Papers { get; set; }
    public required DbSet<Participation> Participations { get; set; }
    public required DbSet<SubmissionRules> SubmissionRuless { get; set; }
    public required DbSet<TimeSlot> TimeSlots { get; set; }
}